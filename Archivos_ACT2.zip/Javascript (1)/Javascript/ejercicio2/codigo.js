var mensaje = "Hola Mundo!";
alert(mensaje);
