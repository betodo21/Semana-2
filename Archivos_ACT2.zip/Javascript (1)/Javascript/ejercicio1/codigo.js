
console.log("Hola Mundo!");
console.log("Soy el primer script");
