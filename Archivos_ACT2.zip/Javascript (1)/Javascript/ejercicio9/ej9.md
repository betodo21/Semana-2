#EJERCICIO 9: Gráficas con ChartJS

Comenzad con la página web proporcionada, que tiene un solo tag img de un GIF animado de un gato caminando.

- Añadid un script en la parte inferior de la página, donde colocaremos todo el código.
- Cread una variable para almacenar una referencia al img del gato.
- Cambiad el estilo del img para que tenga un atributo "left" de "0px", para que comience a la izquierda de la pantalla.
- Cread una función llamada catWalk() que mueva el gato 10 píxeles a la derecha de donde comenzó, cambiando la propiedad CSS "left".
- Llamad a esta función cada 50 milisegundos. El gato ahora debería moverse por la pantalla de izquierda a derecha.

Una vez conseguido lo anterior, cuando el gato llegue a la derecha de la pantalla, reinícialo en el lado izquierdo (left debe valer "0px"). Así que debería seguir caminando de izquierda a derecha por la pantalla, por los siglos de los siglos.

Por último, haced que cuando el gato llegue a la derecha de la pantalla, se mueva hacia atrás, y cuando llegue a la izquierda del todo, se vuelva a mover hacia la derecha. Debería seguir caminando de un lado a otro por los siglos de los siglos.
