var confirmacion = confirm("Hola Mundo!");

if (confirmacion) {
  console.log("Has clicado OK");
} else {
  console.log("Has clicado Cancelar");
}
